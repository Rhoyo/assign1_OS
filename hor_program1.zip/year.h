#include "movies.h"
#ifndef __year
#define __year


void sortYear(struct movie *list, char* inp);


#endif
