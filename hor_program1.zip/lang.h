#include "movies.h"
#ifndef __lang
#define __lang


void sortLang(struct movie *list, char* inp);


#endif
