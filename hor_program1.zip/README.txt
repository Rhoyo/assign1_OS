Compile: gcc --std=gnu99 -o movies main.c rate.c lang.c year.c movies.c

Execute: ./movies file.csv
