#include "movies.h"
#ifndef __rate
#define __rate

int checkList(int in[], int len, int year);
void sortRate(struct movie *list);

#endif
